 <div id="contact-page" class="container">
        <div class="bg">
            <div class="row">           
                <div class="col-sm-12"> 
                <h2 class="title text-center"> <strong></strong></h2>                          
                    <h2 class="title text-center">Contact <strong>Us</strong></h2>   
                    <h2 class="title text-center"> <strong></strong></h2>                                                     
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d918.8377571420663!2d89.49813522917323!3d22.90041993446595!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ff9b93adfc940f%3A0x8459cf9c5b79c481!2sIT%20Incubation%20Centre%2C%20KUET%2C%20Khulna!5e0!3m2!1sen!2sbd!4v1666022814066!5m2!1sen!2sbd" width="1100" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>                  
            </div>      
            <div class="row">   
                <div class="col-sm-8">
                    <div class="contact-form">
                    <h2 class="title text-center"></h2>
                        <h2 class="title text-center">Get In Touch</h2>
                        <div class="status alert alert-success" style="display: none"></div>
                        <form id="main-contact-form" class="contact-form row" name="contact-form" method="post">
                            <div class="form-group col-md-6">
                                <input type="text" name="name" class="form-control" required="required" placeholder="Name">
                            </div>
                            <div class="form-group col-md-6">
                                <input type="email" name="email" class="form-control" required="required" placeholder="Email">
                            </div>
                            <div class="form-group col-md-12">
                                <input type="text" name="subject" class="form-control" required="required" placeholder="Subject">
                            </div>
                            <div class="form-group col-md-12">
                                <textarea name="message" id="message" required="required" class="form-control" rows="8" placeholder="Your Message Here"></textarea>
                            </div>                        
                            <div class="form-group col-md-12">
                                <input type="submit" name="submit" class="btn btn-primary pull-right" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="contact-info">
                    <h2 class="title text-center"></h2>
                        <h2 class="title text-center">Contact Info</h2>
                        <address>
                            <p>BOPON</p>
                            <p>KUET IT PARK</p>
                            <p>Khulna Bangladesh</p>
                            <p>Mobile: 01567954635</p>
                           
                            <p>Email:  arafat2009051@stud.kuet.ac.bd</p>
                        </address>
                        <div class="social-networks">
                            <h2 class="title text-center">Social Networking</h2>
                            <ul>
                                <li>
                                    <a href="https://m.facebook.com/bopon.com.Bd"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-google-plus"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-youtube"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>              
            </div>  
        </div>  
    </div><!--/#contact-page-->